/*	Revision:	4
*/

#include	<stdio.h>
#include	<fcntl.h>

#include	"pl1.h"

static FILE *fpin ;

#define	OLDRECSIZE		128

int convlog(char *oldfn, char *newfn)
{
	LOGREC lr ;
	char oldrec[OLDRECSIZE] ;

	fpin= fopen(oldfn, "r") ;
	if (fpin == (FILE *) NULL) {
		fprintf(stderr, "couldn't open input file: %s\n", oldfn) ;
		return(1) ;
	}

	logfile_Init(newfn) ;
	logfile_CreateAndOpenForWrite(NULL) ;

	while(fgets(oldrec, OLDRECSIZE, fpin) != (char *) NULL) {
		memset(&lr, '\0', sizeof(LOGREC)) ;
		sscanf(
			oldrec,
			"%lu,%d,%d,%s\n",
			&lr.ltime,
			&lr.iaction,
			&lr.icategory,
			lr.szEname
		) ;
		lr.ltime_a= lr.ltime ;
		logfile_PutRec(&lr) ;
	}

	logfile_Close() ;
	logfile_Fini() ;

	fclose(fpin) ;
	return(0) ;
}
