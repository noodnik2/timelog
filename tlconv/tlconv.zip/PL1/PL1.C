#include	<stdio.h>

#include	"pl1.h"

main(int argc, char *argv[])
{
	fprintf(stderr, "in main\n") ;
	if (argc< 3) {
		fprintf(stderr, "specify input, output filenames\n") ;
		exit(1) ;
	}
	fprintf(stderr, "conversion starting\n") ;
	convlog(argv[1], argv[2]) ;
	fprintf(stderr, "conversion done\n") ;
}
