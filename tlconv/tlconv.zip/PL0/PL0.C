/*	Revision:	2
*/

/*

	pl0.c

*/

#include	<stdio.h>
#include	<time.h>

#include	"pl0.h"

static void printhdr(FILE *fpout, char *logfn, LOGHDR *lhp) ;
static void printrec(FILE *fpout, LOGREC *lrp) ;

int printlog(char *logfn, char *tofn)
{
	LOGHDR lh ;
	LOGREC lr ;
	FILE *fpout ;

	fpout= fopen(tofn, "w") ;
	if (fpout == (FILE *) NULL) {
		return(1) ;
	}

	logfile_Init(logfn) ;
	if (logfile_OpenForRead(&lh)) {
		fclose(fpout) ;
		return(2) ;
	}
	
	printhdr(fpout, logfn, &lh) ;
	while(logfile_GetRec(&lr) == 0) printrec(fpout, &lr) ;

	logfile_Close() ;
	logfile_Fini() ;

	fclose(fpout) ;
	return(0) ;
}

/*
	start of internal routines
*/

static void printhdr(FILE *fpout, char *logfn, LOGHDR *lhp)
{
	fprintf(
		fpout,
		"%s: version=%d compatibility=%d\n",
		logfn,
		lhp->ver,
		lhp->compatibility
	) ;
}

static void printrec(FILE *fpout, LOGREC *lrp)
{
	fprintf(
		fpout,
		"%lu,%d,%d,%s\n",
		lrp->ltime,
		lrp->iaction,
		lrp->icategory,
		lrp->szData
	) ;
}

/* end of printlog.c */
