#include	<stdio.h>

#include	"pl0.h"

main(int argc, char *argv[])
{
	fprintf(stderr, "in main\n") ;
	if (argc< 3) {
		fprintf(stderr, "specify input, output filenames\n") ;
		exit(1) ;
	}
	fprintf(stderr, "printlog starting\n") ;
	printlog(argv[1], argv[2]) ;
	fprintf(stderr, "printlog done\n") ;
}

