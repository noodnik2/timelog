/*	Revision:	24
*/

#include	<fcntl.h>
#include	<sys/types.h>
#include	<sys/stat.h>
#include	<string.h>
#include	<io.h>
#include	<stdio.h>
#include	<memory.h>

#include	"logfile.h"

static char szLogFile[MAXSIZE_LOGFILENAME+1] ;
static int fd= -1 ;
static lf_errno= LFE_SUCCESS ;

static int lf_strcpyn(char *s1, char *s2, int nmax) ;

int logfile_errno()
{
	return(lf_errno) ;
}

int logfile_Init(char *pszLogFileUser)
{
	lf_errno= LFE_SUCCESS ;
	if (lf_strcpyn(szLogFile, pszLogFileUser, MAXSIZE_LOGFILENAME+1)) {
		lf_errno= LFE_OVERFLOW ;
		return(1) ;
	}
	return(0) ;
}

int logfile_Fini()
{
	lf_errno= LFE_SUCCESS ;
	return(0) ;
}

int logfile_CreateAndOpenForWrite(LOGHDR *lhp)
{
	LOGHDR lh ;

	lf_errno= LFE_SUCCESS ;
	fd= open(
		szLogFile,
		O_RDWR | O_BINARY | O_CREAT | O_TRUNC,
		S_IREAD | S_IWRITE
	) ;
	if (fd< 0) {
		lf_errno= LFE_CANTCREATE ;
		return(-1) ;
	}

	memset(&lh, '\0', sizeof(LOGHDR)) ;
	lh.ver= LOGFILE_VER ;
	lh.compatibility= LOGFILE_COMPATIBILITY ;

	if (write(fd, &lh, sizeof(LOGHDR)) != sizeof(LOGHDR)) {
		lf_errno= LFE_IOERROR ;
		close(fd) ;
		return(-2) ;
	}

	if (lhp != (LOGHDR *) NULL) memcpy(lhp, &lh, sizeof(LOGHDR)) ;
	return(0) ;
}

int logfile_CheckHeader(LOGHDR *lhp)
{
	LOGHDR lh ;

	lf_errno= LFE_SUCCESS ;
	lseek(fd, 0L, SEEK_SET) ;
	if (read(fd, &lh, sizeof(LOGHDR)) != sizeof(LOGHDR)) {
		lf_errno= LFE_IOERROR ;
		return(-1) ;
	}
	if (lhp != (LOGHDR *) NULL) memcpy(lhp, &lh, sizeof(LOGHDR)) ;
	if (lh.compatibility != LOGFILE_COMPATIBILITY) {
		lf_errno= LFE_INCOMPATIBLE ;
		return(1) ;
	}
	return(0) ;
}

int logfile_OpenForWrite(LOGHDR *lhp)
{
	lf_errno= LFE_SUCCESS ;
	fd= open(szLogFile, O_RDWR | O_BINARY) ;
	if (fd>= 0) {
		if (logfile_CheckHeader(lhp)) {
			close(fd) ;
			fd= -1 ;
			return(1) ;
		}
		return(0) ;
	}
	return(logfile_CreateAndOpenForWrite(lhp)) ;
}

int logfile_OpenForRead(LOGHDR *lhp)
{
	lf_errno= LFE_SUCCESS ;
	fd= open(szLogFile, O_RDONLY | O_BINARY) ;
	if (fd< 0) {
		lf_errno= LFE_CANTOPEN ;
		return(1) ;
	}
	return(logfile_CheckHeader(lhp)) ;
}

int logfile_GetRec(LOGREC *plr)
{
	lf_errno= LFE_SUCCESS ;
	if  (read(fd, plr, sizeof(LOGREC))< sizeof(LOGREC)) {
		lf_errno= LFE_IOERROR ;
		return(-1) ;
	}
	return(0) ;
}

int logfile_PutRec(LOGREC *plr)
{
	lf_errno= LFE_SUCCESS ;
	lseek(fd, 0L, SEEK_END) ;
	if (write(fd, plr, sizeof(LOGREC)) != sizeof(LOGREC)) {
		lf_errno= LFE_IOERROR ;
		return(-1) ;
	}
	return(0) ;
}

void logfile_Close()
{
	if (fd>= 0) {
		close(fd) ;
		fd= -1 ;
	}
}

int logfile_ReadEntry(
	long *pltime,
	int *piaction,
	int *picategory,
	char *pszData,
	int maxdatalen
) {
	LOGREC lr ;
	int rc ;

	lf_errno= LFE_SUCCESS ;

	rc= logfile_GetRec(&lr) ;
	if (rc != 0) return(rc) ;
	
	(*pltime)= lr.ltime ;
	(*piaction)= lr.iaction ;
	(*picategory)= lr.icategory ;
	lf_strcpyn(pszData, lr.szData, maxdatalen) ;

	return(0) ;
}

int logfile_WriteEntry(
	long ltime,
	int iaction,
	int icategory,
	char *pszData
) {
	LOGREC lr ;

	lf_errno= LFE_SUCCESS ;
	/*
		create log record
	*/
	memset(&lr, '\0', sizeof(LOGREC)) ;
	lr.ltime= ltime ;
	lr.iaction= iaction ;
	lr.icategory= icategory ;
	lf_strcpyn(lr.szData, pszData, MAXSIZE_LOGDATA) ;

	/*
		write log record at end of file
	*/
	return(logfile_PutRec(&lr)) ;
}

/*
	internal functions
*/

static int lf_strcpyn(char *s1, char *s2, int nmax)
{
	int ovfl ;

	ovfl= 0 ;
	if (s2 != (char *) NULL) {
		if (((int) strlen(s2))>= nmax) {
			memcpy(s1, s2, nmax-1) ;
			s1[nmax-1]= '\0' ;
			lf_errno= LFE_OVERFLOW ;
			ovfl= 1 ;
		}
		else {
			strcpy(s1, s2) ;
		}
	}
	else {
		s1[0]= '\0' ;
	}
	return(ovfl) ;
}

/* end of logfile.c */
